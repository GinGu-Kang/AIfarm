package kr.ac.cju.acin.window;

public interface onBackPressedListener {
    void onBackPressed();
}
