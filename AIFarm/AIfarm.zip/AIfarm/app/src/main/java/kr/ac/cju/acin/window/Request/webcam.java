package kr.ac.cju.acin.window.Request;

public class webcam {
}
